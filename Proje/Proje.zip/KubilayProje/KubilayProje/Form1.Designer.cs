﻿
namespace KubilayProje
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtsubeid = new System.Windows.Forms.TextBox();
            this.txtkategoriid = new System.Windows.Forms.TextBox();
            this.txtkargono = new System.Windows.Forms.TextBox();
            this.txturunadi = new System.Windows.Forms.TextBox();
            this.txtstok = new System.Windows.Forms.TextBox();
            this.lblAP = new System.Windows.Forms.Label();
            this.lblAS = new System.Windows.Forms.Label();
            this.lblAModel = new System.Windows.Forms.Label();
            this.lblAMarka = new System.Windows.Forms.Label();
            this.btnara = new System.Windows.Forms.Button();
            this.btngncl = new System.Windows.Forms.Button();
            this.btnsil = new System.Windows.Forms.Button();
            this.btnekle = new System.Windows.Forms.Button();
            this.btnlist = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.txturunid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtsatistemsilcisiid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtmusteriid = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtkategoriadi = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtsubeid
            // 
            this.txtsubeid.Location = new System.Drawing.Point(663, 193);
            this.txtsubeid.Name = "txtsubeid";
            this.txtsubeid.Size = new System.Drawing.Size(100, 20);
            this.txtsubeid.TabIndex = 51;
            // 
            // txtkategoriid
            // 
            this.txtkategoriid.Location = new System.Drawing.Point(663, 111);
            this.txtkategoriid.Name = "txtkategoriid";
            this.txtkategoriid.Size = new System.Drawing.Size(100, 20);
            this.txtkategoriid.TabIndex = 50;
            // 
            // txtkargono
            // 
            this.txtkargono.Location = new System.Drawing.Point(663, 152);
            this.txtkargono.Name = "txtkargono";
            this.txtkargono.Size = new System.Drawing.Size(100, 20);
            this.txtkargono.TabIndex = 49;
            // 
            // txturunadi
            // 
            this.txturunadi.Location = new System.Drawing.Point(663, 29);
            this.txturunadi.Name = "txturunadi";
            this.txturunadi.Size = new System.Drawing.Size(100, 20);
            this.txturunadi.TabIndex = 48;
            // 
            // txtstok
            // 
            this.txtstok.Location = new System.Drawing.Point(663, 70);
            this.txtstok.Name = "txtstok";
            this.txtstok.Size = new System.Drawing.Size(100, 20);
            this.txtstok.TabIndex = 47;
            // 
            // lblAP
            // 
            this.lblAP.AutoSize = true;
            this.lblAP.Location = new System.Drawing.Point(568, 156);
            this.lblAP.Name = "lblAP";
            this.lblAP.Size = new System.Drawing.Size(64, 13);
            this.lblAP.TabIndex = 46;
            this.lblAP.Text = "KARGO NO";
            // 
            // lblAS
            // 
            this.lblAS.AutoSize = true;
            this.lblAS.Location = new System.Drawing.Point(568, 116);
            this.lblAS.Name = "lblAS";
            this.lblAS.Size = new System.Drawing.Size(76, 13);
            this.lblAS.TabIndex = 45;
            this.lblAS.Text = "KATEGORİ İD";
            this.lblAS.Click += new System.EventHandler(this.lblAS_Click);
            // 
            // lblAModel
            // 
            this.lblAModel.AutoSize = true;
            this.lblAModel.Location = new System.Drawing.Point(568, 77);
            this.lblAModel.Name = "lblAModel";
            this.lblAModel.Size = new System.Drawing.Size(36, 13);
            this.lblAModel.TabIndex = 44;
            this.lblAModel.Text = "STOK";
            this.lblAModel.Click += new System.EventHandler(this.lblAModel_Click);
            // 
            // lblAMarka
            // 
            this.lblAMarka.AutoSize = true;
            this.lblAMarka.Location = new System.Drawing.Point(568, 36);
            this.lblAMarka.Name = "lblAMarka";
            this.lblAMarka.Size = new System.Drawing.Size(60, 13);
            this.lblAMarka.TabIndex = 43;
            this.lblAMarka.Text = "ÜRÜN ADI";
            // 
            // btnara
            // 
            this.btnara.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnara.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnara.Location = new System.Drawing.Point(838, 94);
            this.btnara.Name = "btnara";
            this.btnara.Size = new System.Drawing.Size(83, 42);
            this.btnara.TabIndex = 42;
            this.btnara.Text = "ARA";
            this.btnara.UseVisualStyleBackColor = false;
            this.btnara.Click += new System.EventHandler(this.btnara_Click);
            // 
            // btngncl
            // 
            this.btngncl.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btngncl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btngncl.Location = new System.Drawing.Point(838, 176);
            this.btngncl.Name = "btngncl";
            this.btngncl.Size = new System.Drawing.Size(83, 42);
            this.btngncl.TabIndex = 41;
            this.btngncl.Text = "GÜNCELLE";
            this.btngncl.UseVisualStyleBackColor = false;
            this.btngncl.Click += new System.EventHandler(this.btngncl_Click);
            // 
            // btnsil
            // 
            this.btnsil.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnsil.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnsil.Location = new System.Drawing.Point(838, 217);
            this.btnsil.Name = "btnsil";
            this.btnsil.Size = new System.Drawing.Size(83, 42);
            this.btnsil.TabIndex = 40;
            this.btnsil.Text = "SİL";
            this.btnsil.UseVisualStyleBackColor = false;
            this.btnsil.Click += new System.EventHandler(this.btnsil_Click);
            // 
            // btnekle
            // 
            this.btnekle.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnekle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnekle.Location = new System.Drawing.Point(838, 135);
            this.btnekle.Name = "btnekle";
            this.btnekle.Size = new System.Drawing.Size(83, 42);
            this.btnekle.TabIndex = 39;
            this.btnekle.Text = "EKLE";
            this.btnekle.UseVisualStyleBackColor = false;
            this.btnekle.Click += new System.EventHandler(this.btnekle_Click);
            // 
            // btnlist
            // 
            this.btnlist.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnlist.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnlist.Location = new System.Drawing.Point(838, 29);
            this.btnlist.Name = "btnlist";
            this.btnlist.Size = new System.Drawing.Size(83, 42);
            this.btnlist.TabIndex = 38;
            this.btnlist.Text = "LİSTELE";
            this.btnlist.UseVisualStyleBackColor = false;
            this.btnlist.Click += new System.EventHandler(this.btnlist_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(536, 268);
            this.dataGridView1.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(568, 196);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 52;
            this.label1.Text = "ŞUBE İD";
            // 
            // txturunid
            // 
            this.txturunid.Location = new System.Drawing.Point(136, 312);
            this.txturunid.Name = "txturunid";
            this.txturunid.Size = new System.Drawing.Size(100, 20);
            this.txturunid.TabIndex = 54;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 319);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 53;
            this.label2.Text = "ÜRÜN İD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 419);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 55;
            this.label3.Text = "MÜŞTERİ İD";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtsatistemsilcisiid
            // 
            this.txtsatistemsilcisiid.Location = new System.Drawing.Point(136, 362);
            this.txtsatistemsilcisiid.Name = "txtsatistemsilcisiid";
            this.txtsatistemsilcisiid.Size = new System.Drawing.Size(100, 20);
            this.txtsatistemsilcisiid.TabIndex = 58;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 369);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 13);
            this.label4.TabIndex = 57;
            this.label4.Text = "SATIŞ TEMSİLCİSİ İD";
            // 
            // txtmusteriid
            // 
            this.txtmusteriid.Location = new System.Drawing.Point(136, 412);
            this.txtmusteriid.Name = "txtmusteriid";
            this.txtmusteriid.Size = new System.Drawing.Size(100, 20);
            this.txtmusteriid.TabIndex = 56;
            this.txtmusteriid.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(267, 400);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 42);
            this.button1.TabIndex = 59;
            this.button1.Text = "SİPARİŞ EKLE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(568, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 61;
            this.label5.Text = "KATEGORİ";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtkategoriadi
            // 
            this.txtkategoriadi.Location = new System.Drawing.Point(663, 229);
            this.txtkategoriadi.Name = "txtkategoriadi";
            this.txtkategoriadi.Size = new System.Drawing.Size(100, 20);
            this.txtkategoriadi.TabIndex = 60;
            this.txtkategoriadi.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(960, 483);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtkategoriadi);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtsatistemsilcisiid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtmusteriid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txturunid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtsubeid);
            this.Controls.Add(this.txtkategoriid);
            this.Controls.Add(this.txtkargono);
            this.Controls.Add(this.txturunadi);
            this.Controls.Add(this.txtstok);
            this.Controls.Add(this.lblAP);
            this.Controls.Add(this.lblAS);
            this.Controls.Add(this.lblAModel);
            this.Controls.Add(this.lblAMarka);
            this.Controls.Add(this.btnara);
            this.Controls.Add(this.btngncl);
            this.Controls.Add(this.btnsil);
            this.Controls.Add(this.btnekle);
            this.Controls.Add(this.btnlist);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtsubeid;
        private System.Windows.Forms.TextBox txtkategoriid;
        private System.Windows.Forms.TextBox txtkargono;
        private System.Windows.Forms.TextBox txturunadi;
        private System.Windows.Forms.TextBox txtstok;
        private System.Windows.Forms.Label lblAP;
        private System.Windows.Forms.Label lblAS;
        private System.Windows.Forms.Label lblAModel;
        private System.Windows.Forms.Label lblAMarka;
        private System.Windows.Forms.Button btnara;
        private System.Windows.Forms.Button btngncl;
        private System.Windows.Forms.Button btnsil;
        private System.Windows.Forms.Button btnekle;
        private System.Windows.Forms.Button btnlist;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtsatistemsilcisiid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtmusteriid;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txturunid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtkategoriadi;
    }
}

